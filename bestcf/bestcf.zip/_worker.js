// 自建 bestcf 优选接口（鲁班版）
// 用法: https://你的域名/bestcf?ips=20&isp=all&port=443&key=密码
// 参数: ips 条数(默认20)  isp=all|ct|cu|cm，可多个如 ct,cm；也可设环境变量 ISP  port 端口(默认443)
//       domain=1 保留第三方优选域名(默认不要)  own=0 不用自己的cfnb结果
// 环境变量(都可不填):
//   KEY      访问密码，设置后必须带 ?key=
//   OWN      自己 cfnb 的 ip.txt 地址
//   SOURCES  第三方源，多个用逗号或换行分隔
//   KV       KV 绑定名(可选)，保存“上次成功的结果”，所有源都挂时用
// 后手顺序: 自己cfnb → 第三方源 → KV里上次成功的结果 → 内置官方段IP

const DEFAULT_OWN = 'https://raw.githubusercontent.com/wsluban168/cfnb-luban/main/ip.txt';
const DEFAULT_SOURCES = [
  'https://090227.pages.dev/bestcf?isp=all&ips=50',
  'https://cf.090227.xyz/ct',
  'https://cf.090227.xyz/cmcc',
  'https://addressesapi.090227.xyz/ct',
  'https://addressesapi.090227.xyz/cmcc',
  'https://addressesapi.090227.xyz/CloudFlareYes',
];
// 最后的后手：Cloudflare 官方段 IP（不依赖任何人）
const BUILTIN = [
  '104.16.240.177', '104.17.22.231', '104.17.125.98', '104.18.33.121',
  '104.19.34.37', '104.26.11.140', '104.26.14.111', '172.66.0.172',
  '172.66.1.250', '172.67.74.177', '172.67.67.89', '188.164.248.18',
  '162.159.192.1', '162.159.36.1', '104.21.48.1', '172.64.32.1',
];
const ISP = { ct: '电信', cu: '联通', cm: '移动' };
const TIMEOUT = 5000;
const CACHE_TTL = 600; // 每个源缓存10分钟

const ISP_RE = {
  ct: /电信|telecom|(^|[^a-z])ct(cc)?([^a-z]|$)/i,
  cu: /联通|unicom|(^|[^a-z])cu(cc)?([^a-z]|$)/i,
  cm: /移动|mobile|(^|[^a-z])cm(cc)?([^a-z]|$)/i,
};
function ispOf(remark) {
  for (const k of ['ct', 'cu', 'cm']) if (ISP_RE[k].test(remark)) return k;
  return '';
}

function list(v, def) {
  if (!v) return def;
  return String(v).split(/[\n,]+/).map(s => s.trim()).filter(Boolean);
}

async function fetchText(url, ctx) {
  const cache = caches.default;
  const key = new Request(url);
  const hit = await cache.match(key);
  if (hit) return hit.text();
  const ac = new AbortController();
  const t = setTimeout(() => ac.abort(), TIMEOUT);
  try {
    const r = await fetch(url, { signal: ac.signal, headers: { 'User-Agent': 'Mozilla/5.0' } });
    if (!r.ok) throw new Error(String(r.status));
    const txt = await r.text();
    ctx.waitUntil(cache.put(key, new Response(txt, { headers: { 'Cache-Control': `max-age=${CACHE_TTL}` } })));
    return txt;
  } finally {
    clearTimeout(t);
  }
}

// 解析一行: 支持 1.2.3.4 / 1.2.3.4:443 / [v6]:443 / 域名:443 加 #备注，也兼容逗号/空格分隔的表格
function parseLine(line, tag) {
  line = line.trim();
  if (!line || line.startsWith('//') || line.startsWith(';')) return null;
  let [addr, remark = ''] = line.split('#');
  addr = addr.trim().split(/[\s,]+/)[0];
  let host = addr, port = '';
  const v6 = addr.match(/^\[([0-9a-fA-F:]+)\](?::(\d+))?$/);
  if (v6) { host = v6[1]; port = v6[2] || ''; }
  else if (/^[^:]+:\d+$/.test(addr)) { [host, port] = addr.split(':'); }
  const isV4 = /^\d{1,3}(\.\d{1,3}){3}$/.test(host);
  const isV6 = /^[0-9a-fA-F:]+$/.test(host) && host.includes(':');
  const isDomain = /^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(host);
  if (!isV4 && !isV6 && !isDomain) return null;
  return { host, port, remark: remark.trim(), tag, isDomain };
}

function parse(txt, tag) {
  return txt.split(/\r?\n/).map(l => parseLine(l, tag)).filter(Boolean);
}

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const q = url.searchParams;

    if (env.KEY && q.get('key') !== env.KEY) {
      return new Response('403', { status: 403 });
    }
    if (url.pathname !== '/bestcf' && url.pathname !== '/') {
      return new Response('Not Found', { status: 404 });
    }

    const n = Math.min(Math.max(parseInt(q.get('ips') || '20', 10) || 20, 1), 200);
    const port = q.get('port') || '443';
    const isps = (q.get('isp') || env.ISP || 'all').toLowerCase().split(/[,|]/).map(x => x.trim()).filter(x => ISP[x]);
    const keepDomain = q.get('domain') === '1';
    const useOwn = q.get('own') !== '0';

    const jobs = [];
    if (useOwn) jobs.push({ url: env.OWN || DEFAULT_OWN, tag: '自测' });
    for (const s of list(env.SOURCES, DEFAULT_SOURCES)) jobs.push({ url: s, tag: '第三方' });

    const results = await Promise.allSettled(jobs.map(j => fetchText(j.url, ctx).then(t => parse(t, j.tag))));
    const status = results.map((r, i) => `${jobs[i].tag}:${r.status === 'fulfilled' ? r.value.length : '失败'}`);

    let items = [];
    for (const r of results) if (r.status === 'fulfilled') items.push(...r.value);

    // 去掉第三方域名（别人的域名随时会失效）
    if (!keepDomain) items = items.filter(x => !x.isDomain || x.tag === '自测');

    // 按运营商筛选（只作用于带运营商备注的第三方条目，自测的全保留）
    if (isps.length) items = items.filter(x => x.tag === '自测' || isps.includes(ispOf(x.remark)));

    // 去重，保持顺序：自测在前
    const seen = new Set();
    items = items.filter(x => (seen.has(x.host) ? false : (seen.add(x.host), true)));

    let from = 'live';
    if (items.length && env.KV) {
      ctx.waitUntil(env.KV.put('last', JSON.stringify(items)));
    }
    if (!items.length && env.KV) {
      const last = await env.KV.get('last', 'json');
      if (last && last.length) { items = last; from = 'kv'; }
    }
    if (!items.length) {
      items = BUILTIN.map(h => ({ host: h, port: '', remark: '', tag: '内置' }));
      from = 'builtin';
    }

    const out = items.slice(0, n).map(x => {
      const h = x.host.includes(':') ? `[${x.host}]` : x.host;
      const name = { 自测: x.remark ? `自测 ${x.remark}` : '自测优选', 第三方: ispOf(x.remark) ? `CF ${ISP[ispOf(x.remark)]}` : '第三方优选', 内置: '官方段' }[x.tag];
      return `${h}:${x.port || port}#${name}`;
    });

    return new Response(out.join('\n') + '\n', {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        'Cache-Control': 'no-store',
        'X-Source-Status': encodeURIComponent(status.join(' ')),
        'X-From': from,
      },
    });
  },
};
